# raw_data_processing

This folder contains files related to raw_data_processing.